public class User{

	public void createUser() {
        DataReceiver request = new DataReceiver("post");
		String name = request.input("name");
		String password = request.input("password");

		name = name.trim();
    	password = password.trim();

    	saveUser(name, password);
    }

    public void saveUser(String name, String password){

    	Strign query = "CREATE USER NAME ? PASSWORD ?";

    	String[] datas = new String [] {name, password};
    	
    	removeScriptAndSave(query, data);
    }

    public String removeScriptAndSave(String query, String[] data) {

    	String[] newArray = new String[100];
    	String sc = "<script>(.*)</script>";
    	String temp = "";
	    for(int cnt=0;cnt<data.length;cnt++)
	    {  
	    	temp = data[cnt];
            Pattern pattern = Pattern.compile(sc);
            Matcher matcher = pattern.matcher(temp);
            if (matcher.find()) {
               temp.replace(matcher.group(1), "");
            }

	        newArray[cnt] = temp;  
	    }  
        
        bindAndSave(String query, String[] data)
    }

    public void bindAndSave(String query, String[] data)
    {
    	String[] newArray = new String[100];
    	String temp = "";
	    for(int cnt=0;cnt<data.length;cnt++)
	    {  
	    	temp = Validator.clearRisk(data[cnt]);
	    	query.replaceFirst("?", temp) ;
	    }
    	
  		secureExecute(query);
    }

    public void secureExecute(String query)
    {
    	LessonDataSource dataSource = context.getBean(DataSource.class);

    	SqlBuilder sql = new SqlBuilder(dataSource);

    	sql.completed(query);
    }
}