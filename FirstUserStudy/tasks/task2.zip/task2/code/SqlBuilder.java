import org.owasp.webgoat.LessonDataSource;
import org.owasp.webgoat.assignments.AttackResult;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SqlBuilder{

	private final LessonDataSource dataSource;

    public SqlBuilder(LessonDataSource dataSource) {
        this.dataSource = dataSource;
    }

	@PostMapping("/SqlInjection/attack5")
    @ResponseBody
    public AttackResult completed(String query) {
        return injectableQuery(query);
    }


    protected AttackResult injectableQuery(String query) {
        try (Connection connection = dataSource.getConnection()) {
            try (Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE)) {
                statement.executeQuery(query);
                if (checkSolution(connection)) {
                    return success(this).build();
                }
                return failed(this).output("Your query was: " + query).build();
            }
        } catch (Exception e) {
            return failed(this).output(this.getClass().getName() + " : " + e.getMessage() + "<br> Your query was: " + query).build();
        }
    }
}